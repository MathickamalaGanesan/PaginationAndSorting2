CREATE TABLE Employee(
	id INT,
	name VARCHAR(10),
	dept VARCHAR(10),
	salary INT
);
INSERT INTO Employee VALUES(1, 'sita' , 'IT', 20000);
INSERT INTO Employee VALUES(2, 'geeta' , 'CSC', 20000);
INSERT INTO Employee VALUES(3, 'reeta' , 'IT', 20000);
INSERT INTO Employee VALUES(4, 'suba' , 'IT', 20000);
INSERT INTO Employee VALUES(5, 'ramba' , 'IT', 20000);