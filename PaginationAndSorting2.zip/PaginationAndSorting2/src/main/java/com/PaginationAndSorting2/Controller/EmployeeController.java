package com.PaginationAndSorting2.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.PaginationAndSorting2.Repository.EmployeeRepository;
import com.PaginationAndSorting2model.Employee;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeRepository empRepo;

	@GetMapping("/employees")
	public Page<Employee> getAllEmployee(
	@RequestParam Optional<String> name,
	@RequestParam Optional<Integer> pageNumber,
	@RequestParam Optional<Integer> pageSize,
	@RequestParam Optional<String> sortBy
	){
		return empRepo.findAllByNameContainingIgnoreCase(name.orElse(""), 
				PageRequest.of(pageNumber.orElse(0), pageSize.orElse(10),Sort.by(Sort.Direction.ASC,sortBy.orElse("id"))));
	}

}
